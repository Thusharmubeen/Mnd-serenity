# MIND-SERENITY---ANXIETY-REDUCTION-VIRTUAL-REALITY
This project is to the benefit of the patients who are suffering from Anxiety and stress. It is VR project built on Unity in order to reduce Anxiety and stress with personalised modules!
